import os,subprocess,csv
from appium import webdriver
from appium.webdriver.common.touch_action import TouchAction
from selenium.webdriver.common.by import By


class Info:
    def __init__(self,ip='localhost',port=62001,device=False):
        if os.system('adb --version 1>nul 2>nul')==0:
            if device:
                pass
            else:
                cmd = 'adb connect %s:%s' %(ip,port) 
                work = subprocess.Popen(cmd,shell=True)
                work.wait()
        else:
            raise Exception('检查adb环境')

    def get_platform_name(self):
        cmd = 'adb shell getprop net.bt.name'
        data = list(os.popen(cmd))[0].strip()
        return data

    def get_platform_version(self):
        cmd = 'adb shell getprop ro.build.version.release'
        data = list(os.popen(cmd))[0].strip()
        return data

    def get_device_name(self):
        cmd = 'adb devices'
        data = list(os.popen(cmd))
        device = [i for i in data if i.strip().endswith('device')][0].strip()
        return device

    def get_package_name(self,apkpath):
        cmd = 'aapt dumpsys badging %s|findstr package' %apkpath
        data = os.popen(cmd)
        package_name = data.buffer.read().decode('utf8').split("'")[1]
        return package_name

    def get_activity(self,apkpath):
        cmd = 'aapt dumpsys badging %s|findstr activity' %apkpath
        data = os.popen(cmd)
        activity = data.buffer.read().decode('utf8').split("'")[1]
        return activity

    def install_apk(self,apkpath):
        package_name = self.get_package_name(apkpath)
        cmd = 'adb shell pm list packages|findstr %s' %package_name
        flag = list(os.popen(cmd))
        if flag:
            print('程序已安装')
        else:
            work = subprocess.Popen('adb install %s' %apkpath,shell=True)
            work.wait()
            print('程序安装成功')

    def uninstall_app(self,package_name):
        cmd = 'adb shell pm list packages|findstr %s' % package_name
        flag = list(os.popen(cmd))
        if flag:
            os.popen('adb uninstall %s' %package_name)
            print('程序卸载成功')
        else:
            print('程序未安装')

    def clear_app(self,package_name):
        cmd = 'adb shell pm clear %s' %package_name
        os.popen(cmd)

class Base:

    def __init__(self,device:dict,host='localhost',port=4723):
        if 'platformName' in device.keys():
            self.driver = webdriver.Remote('http://%s:%s/wd/hub' %(host,port),device)
        else:
            raise Exception('传入的设备信息不合法')

    def open_app(self,app_package, app_activity,**opts):
        self.driver.start_activity(app_package, app_activity,**opts)

    def swipe(self,where,duration=300):
        size = self.driver.get_window_size()
        width = size['width']
        height = size['height']
        if where in ('u','up'):
            self.driver.swipe(start_x=int(width/2),start_y=int(height*0.9),
                              end_x=int(width/2),end_y=int(height*0.1),duration=duration)
        elif where in ('d','down'):
            self.driver.swipe(start_x=int(width/2),start_y=int(height*0.1),
                              end_x=int(width/2),end_y=int(height*0.9),duration=duration)
        elif where in ('l','left'):
            self.driver.swipe(start_x=int(width*0.9), start_y=int(height/2),
                              end_x=int(width*0.1),end_y=int(height/2),duration=duration)
        elif where in ('r','right'):
            self.driver.swipe(start_x=int(width*0.1), start_y=int(height/2),
                              end_x=int(width*0.9),end_y=int(height/2),duration=duration)
        else:
            raise Exception('不支持其他方向')

    def __convert_selector_to_locator(self,selector):
        selector_key = selector.split(',')[0]
        selector_value = selector.split(',')[1]
        if selector_key in ('i','id'):
            locator = (By.ID,selector_value)
        elif selector_key in ('x','xpath'):
            locator = (By.XPATH,selector_value)
        else:
            raise Exception('原生方法只支持id/xpath定位')
        return locator

    def get_element(self,selector):
        selector_key = selector.split(',')[0]
        selector_value = selector.split(',')[1]
        if selector_key in ('i','id','x','xpath'):
            locator = self.__convert_selector_to_locator(selector)
            element = self.driver.find_element(*locator)
        elif selector_key in ('t','text'): 
            element = self.driver.find_element_by_android_uiautomator('new UiSelector().text("%s")' %selector_value)
        elif selector_key in ('r','resourceId'):
            element = self.driver.find_element_by_android_uiautomator('new UiSelector().resourceId("%s")' % selector_value)
        elif selector_key in ('c','className'):
            element = self.driver.find_element_by_android_uiautomator('new UiSelector().className("%s")' % selector_value)
        else:
            raise Exception('传入的元素选择器不合法')
        return element

    def implicitly_wait(self,second=10):
        self.driver.implicitly_wait(second)

    def keyevent(self,keycode):
        self.driver.keyevent(keycode)

    def long_press(self,selector,duration=1500):
        element = self.get_element(selector)
        TouchAction(self.driver).long_press(element,duration=duration).perform()

class BasePage:

    def __init__(self,base:Base):
        self.base = base





if __name__ == '__main__':
    info = Info()
