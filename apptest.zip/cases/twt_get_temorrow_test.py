import unittest,warnings
from bases.base import Info, Base
from pages.twt_get_temorrow_page import TWT_Temorrow
from pages.twt_request_info import TWT_Request
from pages.twt_welcome import TWT_Welcome


class TWT_Temorrow_test(unittest.TestCase):
    info = Info()
    apk = r'D:\appium\wodetianwentai.apk'
    device = {
        'platformName': info.get_platform_name(),
        'platformVersion': info.get_platform_version(),
        'deviceName': info.get_device_name()
    }
    package_name = info.get_package_name(apk)
    activity = info.get_activity(apk)
    apk_info = (package_name, activity)

    @classmethod
    def setUpClass(self):
        warnings.simplefilter('ignore',ResourceWarning)
        self.info.install_apk(self.apk)
        self.info.clear_app(self.apk_info[0])
    @classmethod
    def tearDownClass(self):
        pass
    def setUp(self):
        self.base = Base(self.device)
        self.base.open_app(*self.apk_info)
        TWT_Welcome(self.base).welcome()
    def tearDown(self):
        self.info.clear_app(self.apk_info[0])
    def test_get_temorrow_weather(self):
        app_weather_info = TWT_Temorrow(self.base).get_temorrow_weather()
        res_weather_info = TWT_Request().get_info()['forecast_detail'][0]
        #用例设计:appui界面获取的数据和接口返回的数据进行比对
        print(app_weather_info)
        print(res_weather_info)
        self.assertTrue(app_weather_info[2]==res_weather_info['wind_info'] and app_weather_info[3]==res_weather_info['wx_desc'],msg='app与api返回信息不一致')
if __name__ == '__main__':
    unittest.main(verbosity=2)