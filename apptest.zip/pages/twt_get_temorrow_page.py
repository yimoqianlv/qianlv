from bases.base import BasePage

class TWT_Temorrow(BasePage):

    def get_temorrow_weather(self):
        base = self.base
        base.get_element('x,//android.widget.ImageButton[@content-desc="Navigate up"]').click()
        base.get_element('i,hko.MyObservatory_v1_0:id/ocf_title').click()
        temp = base.get_element('r,hko.MyObservatory_v1_0:id/sevenday_forecast_temp').text
        rh = base.get_element('r,hko.MyObservatory_v1_0:id/sevenday_forecast_rh').text
        wind = base.get_element('r,hko.MyObservatory_v1_0:id/sevenday_forecast_wind').text
        details = base.get_element('r,hko.MyObservatory_v1_0:id/sevenday_forecast_details').text
        return temp,rh,wind,details