import requests

class TWT_Request:
    def get_info(self):
        url = 'http://pda.weather.gov.hk/locspc/android_data/fnd_uc.xml?-0.6184104599738681'
        res = requests.get(url)
        res.encoding = res.apparent_encoding
        return res.json()
# 获取后天的相对湿度：
if __name__ == '__main__':
    after_tomorrow_min_rh = TWT_Request().get_info()['forecast_detail'][1]['min_rh']
    after_tomorrow_max_rh = TWT_Request().get_info()['forecast_detail'][1]['max_rh']
    print('后天的相对湿度为{}度-{}度'.format(after_tomorrow_min_rh,after_tomorrow_max_rh))