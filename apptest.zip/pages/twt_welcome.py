from bases.base import BasePage


class TWT_Welcome(BasePage):

    def welcome(self):
        base = self.base
        base.implicitly_wait()
        while True:
            try:
                base.get_element('i,hko.MyObservatory_v1_0:id/btn_agree').click()
            except:
                break
        while True:
            try:
                base.get_element('i,hko.MyObservatory_v1_0:id/btn_friendly_reminder_skip').click()
            except:
                break
